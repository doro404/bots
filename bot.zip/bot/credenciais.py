CREDENTIALS = {
    'client_id': '',
    "client_secret": '',
    "sandbox": False,
    "certificate": 'certificado.pem'
}